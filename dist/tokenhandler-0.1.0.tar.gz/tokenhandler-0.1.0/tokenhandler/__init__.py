"""
tokenhandler.

Token Handler (as python library) for the SALTED broker architecture.
"""

__version__ = "0.1.0"
__author__ = 'Maren Dietzel'
