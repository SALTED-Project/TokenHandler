"""
tokenhandler.

Token Handler (as python library) for the SALTED broker architecture.
"""

__version__ = "0.1.2"
__author__ = 'Maren Dietzel'
